#ifndef CARCTICFOX_H
#define CARCTICFOX_H

#pragma once
#include "CPredator.h"
#include <string>
class CArcticFox : public CPredator
{
public:
	virtual ~CArcticFox() {};
	CArcticFox(const std::string& nickname, unsigned& population): CPredator(nickname, "ArcticFox", population) {};
protected:
	virtual unsigned ReproductionRound() { return 8; };
	virtual unsigned DividedNumber() { return 4; };
	virtual unsigned BornNumbers() { return 3; };
};
#endif
