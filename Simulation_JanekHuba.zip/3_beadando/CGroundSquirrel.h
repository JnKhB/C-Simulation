#ifndef CGROUNDSQUIRREL_H
#define CGROUNDSQUIRREL_H

#pragma once
#include "CPrey.h"
#include <string>
class CGroundSquirrel : public CPrey
{
public:
	virtual ~CGroundSquirrel() {};
	CGroundSquirrel(const std::string& nickname, unsigned& population) :CPrey(nickname, "GroundSquirrel", population) {};
protected:
	virtual unsigned ReproductionRound() { return 4; };
	virtual double ReproductionMultiplier() { return 2; };
	virtual unsigned PopulationLimit() { return 200; };
	virtual unsigned PopulationRestore() { return 40; };
	virtual unsigned HunterMultiplier() { return 2; };

};
#endif
