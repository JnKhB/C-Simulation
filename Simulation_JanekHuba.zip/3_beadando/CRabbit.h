#ifndef CRABBIT_H
#define CRABBIT_H
#pragma once

#include "CPrey.h"
#include <string>
class CRabbit : public CPrey
{
public:
	virtual ~CRabbit() {};
	CRabbit(const std::string& nickname, unsigned& population) :CPrey(nickname, "Rabbit", population) {};
protected:
	virtual unsigned ReproductionRound() { return 2; };
	virtual double ReproductionMultiplier() { return 1.5; };
	virtual unsigned PopulationLimit() { return 100; };
	virtual unsigned PopulationRestore() { return 20; };
	virtual unsigned HunterMultiplier() { return 2; };
};

#endif