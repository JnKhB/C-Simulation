#include "CPredator.h"
#include <math.h>
#include <iostream>
#include <fstream>
#include <cassert>  

#ifdef _PREDEFINED
bool CPredator::s_randomized = false;
#else 
bool CPredator::s_randomized = true;
#endif
std::vector<unsigned> CPredator::s_numbers;
unsigned CPredator::s_index = 0; 

void CPredator::Reproduction(unsigned numberOfRound)
{
	if (numberOfRound % ReproductionRound() == 0)
	{
		m_population += ((unsigned)(m_population / DividedNumber()) * BornNumbers());
	}
}
void CPredator::Hunt(std::vector<CPrey*>& preys)
{
	unsigned randomNumber = NextPrey(preys.size());
	
	if (preys[randomNumber]->Reduction(this) == false)
	{
		m_population -= (m_population/4);
	}
}
void CPredator::ReadNumbers(const std::string& filename)
{
	s_numbers.clear();
	s_index = 0;
	std::ifstream ifs(filename);
	unsigned number; 
	while (!ifs.fail())
	{
		ifs >> number;
		if (!ifs.fail())
		{
			s_numbers.push_back(number);
		}
	}

}
unsigned CPredator::NextPrey(unsigned numberOfPreys)
{
	if (s_randomized)
	{
		return rand() % numberOfPreys;
	}
	else
	{
		assert(s_index < s_numbers.size());
		return s_numbers[s_index++];
	}
	
}

