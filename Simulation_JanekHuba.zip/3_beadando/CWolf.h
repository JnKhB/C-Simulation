#pragma once
#ifndef CWOLF_H
#define CWOLF_H
#include "CPredator.h"
#include <string>
class CWolf : public CPredator
{
public:
	virtual ~CWolf() {};
	CWolf(const std::string& nickname, unsigned& population): CPredator(nickname, "Wolf", population) {};
protected:
	virtual unsigned ReproductionRound() { return 8; };
	virtual unsigned DividedNumber() { return 4; };
	virtual unsigned BornNumbers() { return 2; };
};
#endif
