
#ifndef CANIMAL_H
#define CANIMAL_H
#include <string>
#include <iostream>
class CAnimal
{
public:
	virtual ~CAnimal() {};
	std::string Nickname() const { return m_nickname; }
	std::string Species() const { return m_species; }
	unsigned Population() const { return m_population; }
	virtual void Reproduction(unsigned numberOfRound) = 0;
	friend std::ostream& operator<<(std::ostream& os, const CAnimal& animal);
protected:
	CAnimal(const std::string& nickname, const std::string& species, unsigned& population) : m_nickname(nickname), m_species(species), m_population(population) {};
	std::string m_nickname;
	std::string m_species;
	unsigned m_population;
};
#endif
