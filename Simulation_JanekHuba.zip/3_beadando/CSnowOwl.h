
#pragma once
#ifndef CSNOWOWL_H
#define CSNOWOWL_H
#include "CPredator.h"
#include <string>
class CSnowOwl : public CPredator
{
public:
	virtual ~CSnowOwl() {};
	CSnowOwl(const std::string& nickname, unsigned& population): CPredator(nickname, "SnowOwl", population) {};
protected: 
	virtual unsigned ReproductionRound() { return 8; };
	virtual unsigned DividedNumber() { return 4; };
	virtual unsigned BornNumbers() { return 1; };
};

#endif