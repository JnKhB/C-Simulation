#ifndef CLEMMING_H
#define CLEMMING_H
#pragma once
#include "CPrey.h"
#include <string>
class CLemming : public CPrey
{
public:
	virtual ~CLemming() {};
	CLemming(const std::string& nickname, unsigned& population) :CPrey(nickname, "Lemming", population){};
protected:
	virtual unsigned ReproductionRound() { return 2; };
	virtual double ReproductionMultiplier() { return 2; };
	virtual unsigned PopulationLimit() { return 200; };
	virtual unsigned PopulationRestore() { return 30; };
	virtual unsigned HunterMultiplier() { return 4; };
};
#endif