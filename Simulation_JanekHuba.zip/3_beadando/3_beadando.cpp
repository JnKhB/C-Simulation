#include "CLemming.h"
#include "CRabbit.h"
#include "CGroundSquirrel.h"
#include "CArcticFox.h"
#include "CWolf.h"
#include "CSnowOwl.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <iostream>
#include <time.h>
using namespace std;

void read(const string& filename, vector<CPrey*> &preys, vector<CPredator*> &predators)
{
	ifstream ifs(filename);
	if (ifs.fail())
	{
		cout << "Wrong filename" << endl;
		exit(1);
	}
	unsigned numberOfPreys = 0;
	unsigned numberOfPredators = 0;
	ifs >> numberOfPreys >> numberOfPredators;
	for (unsigned i = 0; i < numberOfPreys; i++)
	{
		string nickname;
		string species;
		unsigned population;
		ifs >> nickname >> species >> population;
		if (species == "l")
		{
			preys.push_back(new CLemming(nickname, population)); 
		}
		if (species == "n")
		{
			preys.push_back(new CRabbit(nickname, population));
		}
		if (species == "u")
		{
			preys.push_back(new CGroundSquirrel(nickname, population));
		}	
	}
	for (unsigned i = 0; i < numberOfPredators; i++)
	{
		string nickname;
		string species;
		unsigned population;
		ifs >> nickname >> species >> population;
		if (species == "h")
		{
			predators.push_back(new CSnowOwl(nickname, population));
		}
		if (species == "f")
		{
			predators.push_back(new CWolf(nickname, population));
		}
		if (species == "s")
		{
			predators.push_back(new CArcticFox(nickname, population));
		}
	}
}
unsigned CountPredators(vector<CPredator*>& predators)
{
	unsigned predatorCount = 0; 
	for (unsigned i = 0; i < predators.size(); i++)
	{
		predatorCount += predators[i]->Population(); 
	}
	return predatorCount; 
}
bool EndOfSimulation(vector<CPredator*>& predators, unsigned originalNumberOfPredators)
{
	vector<unsigned> sumOfPopulations;
	bool populationIsTooLow = true;
	for (unsigned i = 0; i < predators.size() && populationIsTooLow; i++)
	{
		if (predators[i]->Population() >= 4)
		{
			populationIsTooLow = false;
		}
	}
	bool populationIsTooHigh = originalNumberOfPredators * 2 < CountPredators(predators); 
	return populationIsTooHigh || populationIsTooLow; 
}
template <typename Item>
void print(const vector<Item*>& vec)
{
	for (Item* ptr : vec)
	{
		cout << *ptr << endl;
	}
}
void Simulation(vector<CPrey*>& preys, vector<CPredator*>& predators)
{
	unsigned originalCount = CountPredators(predators);
	
	for (unsigned numberOfRound = 1; !EndOfSimulation(predators, originalCount); numberOfRound++)
	{
		cout << endl << "*** Round: " << numberOfRound << " ***" << endl;
		for (unsigned j = 0; j < preys.size(); j++)
		{
			preys[j]->Reproduction(numberOfRound);
		}
		for (unsigned j = 0; j < predators.size(); j++)
		{
			predators[j]->Reproduction(numberOfRound);
		}
		// tegy�k fel, hogy egy szimul�lt k�r a k�vetkez�ekb�l �ll: Mindenki n�, amennyivel n�nie kell, �s ut�na a Ragadoz�k mindegyik�t vad�szni k�ldj�k. 
		for (unsigned j = 0; j < predators.size(); j++)
		{
			predators[j]->Hunt(preys); 
		}
		print(preys);
		print(predators);
	}
}

void SimulationOfOneRound(vector<CPrey*>& preys, vector<CPredator*>& predators, unsigned numberOfRound)
{
		
		cout << endl << "*** Round: " << numberOfRound << " ***" << endl;
		for (unsigned j = 0; j < preys.size(); j++)
		{
			preys[j]->Reproduction(numberOfRound);
		}
		for (unsigned j = 0; j < predators.size(); j++)
		{
			predators[j]->Reproduction(numberOfRound);
		}
		// tegy�k fel, hogy egy szimul�lt k�r a k�vetkez�ekb�l �ll: Mindenki n�, amennyivel n�nie kell, �s ut�na a Ragadoz�k mindegyik�t vad�szni k�ldj�k. 
		for (unsigned j = 0; j < predators.size(); j++)
		{
			predators[j]->Hunt(preys);
		}
		print(preys);
		print(predators);
}	
void ClearPreys(vector<CPrey*>& preys) 
{
	for (unsigned i = 0; i < preys.size();i++)
	{
		delete preys[i];
	}
	preys.clear();
}
void ClearPredators(vector<CPredator*>& predators)
{
	for (unsigned i = 0; i < predators.size();i++)
	{
		delete predators[i];
	}
	predators.clear();
}

#define NORMAL_MODE
#ifdef NORMAL_MODE

int main()
{
//If you want to get random numbers, you should run release mode. The debug mode is for test cases. It runs with the number of numbers.txt so it is possible to follow the input file changes.
#ifdef _PREDEFINED
	cout << "Add the name of the predefinition file: ";
	string numberfilename;
	cin >> numberfilename;
	CPredator::ReadNumbers(numberfilename); 
#else
	srand((unsigned int)time(NULL));
#endif

	vector<CPrey*> preys;
	vector<CPredator*> predators;
	read("input3.txt", preys, predators); 
	unsigned numberOfPreys = preys.size();
	unsigned numberOfPredators = predators.size();
	cout << "***The input file***" << endl;
	cout << numberOfPreys << " " << numberOfPredators << endl;
	print(preys);
	print(predators);
	Simulation(preys, predators);
	ClearPreys(preys);
	ClearPredators(predators);
}
#else
#define CATCH_CONFIG_MAIN
#include "catch.hpp"
//Check for empty file
TEST_CASE("Empty file", "input0.txt")
{
	vector<CPrey*> preys;
	vector<CPredator*> predators;
	read("input0.txt", preys, predators);
	CHECK(preys.size() == 0);
	CHECK(predators.size() == 0);
	ClearPreys(preys);
	ClearPredators(predators);
}
// Check a not empty file, test step by step, each round is tested - input.txt and numbers.txt
TEST_CASE("Each round's result is tested by step by step", "input.txt - numbers.txt")
{
	cout << "***Simulation by step by step***" << endl;
	CPredator::ReadNumbers("numbers.txt");
	vector<CPrey*> preys;
	vector<CPredator*> predators;
	read("input.txt", preys, predators);
	unsigned numberOfRound = 1;
	//The input's state
	CHECK(preys[0]->Population() == 86);
	CHECK(preys[1]->Population() == 90);
	CHECK(preys[2]->Population() == 10);
	CHECK(preys[3]->Population() == 10);
	CHECK(predators[0]->Population() == 5);
	CHECK(predators[1]->Population() == 5);
	SimulationOfOneRound(preys, predators, numberOfRound);
	//The states after simulation first round
	CHECK(preys[0]->Population() == 86);
	CHECK(preys[1]->Population() == 90);
	CHECK(preys[2]->Population() == 0);
	CHECK(preys[3]->Population() == 0);
	CHECK(predators[0]->Population() == 5);
	CHECK(predators[1]->Population() == 5);
	numberOfRound++;		
	SimulationOfOneRound(preys, predators, numberOfRound);
	//The states after simulation second round
	CHECK(preys[0]->Population() == 172);
	CHECK(preys[1]->Population() == 180);
	CHECK(preys[2]->Population() == 0);
	CHECK(preys[3]->Population() == 0);
	CHECK(predators[0]->Population() == 4);
	CHECK(predators[1]->Population() == 4);
	numberOfRound++;
	SimulationOfOneRound(preys, predators, numberOfRound);
	//The states after simulation third round
	CHECK(preys[0]->Population() == 172);
	CHECK(preys[1]->Population() == 180);
	CHECK(preys[2]->Population() == 0);
	CHECK(preys[3]->Population() == 0);
	CHECK(predators[0]->Population() == 3);
	CHECK(predators[1]->Population() == 3);
	ClearPreys(preys);
	ClearPredators(predators);
}
TEST_CASE("tested only the final result with Simulation() function", "input.txt - numbers.txt")
{
	cout << "***Simulation with the Simulation() function check the final result***" << endl;
	CPredator::ReadNumbers("numbers.txt");
	vector<CPrey*> preys;
	vector<CPredator*> predators;
	read("input.txt", preys, predators);
	Simulation(preys, predators); 
	CHECK(preys[0]->Population() == 172);
	CHECK(preys[1]->Population() == 180);
	CHECK(preys[2]->Population() == 0);
	CHECK(preys[3]->Population() == 0);
	CHECK(predators[0]->Population() == 3);
	CHECK(predators[1]->Population() == 3);
	ClearPreys(preys);
	ClearPredators(predators);
}
// testcase for input2.txt and numbers2.txt
TEST_CASE("Test for 2 preys and 1 predator", "input.txt - numbers.txt")
{
	cout << "***Simulation with the Simulation() function check the final result***" << endl;
	CPredator::ReadNumbers("numbers2.txt");
	vector<CPrey*> preys;
	vector<CPredator*> predators;
	read("input2.txt", preys, predators);
	CHECK(preys[0]->Population() == 20);
	CHECK(preys[1]->Population() == 90);
	CHECK(predators[0]->Population() == 5);
	Simulation(preys, predators);
	CHECK(preys[0]->Population() == 0);
	CHECK(preys[1]->Population() == 30);
	CHECK(predators[0]->Population() == 3);
	ClearPreys(preys);
	ClearPredators(predators);
	cout << endl;
}
//testcase for input3.txt and numbers3.txt - A more complicated simulation
TEST_CASE("Test for many preys and predators", "input3.txt - numbers3.txt")
{
	CPredator::ReadNumbers("numbers3.txt");
	vector<CPrey*> preys;
	vector<CPredator*> predators;
	read("input3.txt", preys, predators);
	cout << "The input" << endl;
	unsigned numberOfPreys = preys.size();
	unsigned numberOfPredators = predators.size();
	cout << numberOfPreys << " " << numberOfPredators << endl;
	print(preys);
	print(predators);
	Simulation(preys, predators);
	//The states after simulation first round	
	CHECK(preys[0]->Population() == 112);
	CHECK(preys[1]->Population() == 136);
	CHECK(preys[2]->Population() == 0);
	CHECK(preys[3]->Population() == 0);
	CHECK(preys[4]->Population() == 60);
	CHECK(predators[0]->Population() == 3);
	CHECK(predators[1]->Population() == 3);
	CHECK(predators[2]->Population() == 3);
	CHECK(predators[3]->Population() == 3);
}
#endif