#include "CAnimal.h"
#include <iostream>
std::ostream& operator<<(std::ostream& os, const CAnimal& animal)
{
	os << animal.m_nickname << " " << animal.m_species << " " << animal.m_population;
	return os;
}