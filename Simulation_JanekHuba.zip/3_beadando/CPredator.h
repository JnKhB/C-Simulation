#ifndef CPREDATOR_H
#define CPREDATOR_H
#include "CAnimal.h"
#include "CPrey.h"
#include <vector>
#include <string>
class CPredator:public CAnimal
{
public:
	 ~CPredator() {};
	 virtual void Reproduction(unsigned numberOfRound);
	 void Hunt(std::vector<CPrey*> &preys);
	 static void ReadNumbers(const std::string &filename); 

protected:
	CPredator(const std::string& nickname, const std::string& species, unsigned& population) : CAnimal(nickname, species, population) {};
	virtual unsigned ReproductionRound() = 0; 
	virtual unsigned DividedNumber() = 0;
	virtual unsigned BornNumbers() = 0;
	static unsigned NextPrey(unsigned numberOfPreys);
private:
	static bool s_randomized;
	static std::vector<unsigned> s_numbers; 
	static unsigned s_index; 
};
#endif