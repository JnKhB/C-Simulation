#ifndef CPREY_H
#define CPREY_H
#pragma once
#include <string>
#include "CAnimal.h"

class CPrey:public CAnimal
{
public:
	virtual ~CPrey() {};
	virtual void Reproduction(unsigned numberOfRound);
	bool Reduction(const CAnimal* pDependsOn);
protected:
	CPrey(const std::string& nickname, const std::string& species, unsigned& population) : CAnimal(nickname, species, population) {};
	virtual unsigned ReproductionRound() = 0; 
	virtual double ReproductionMultiplier() = 0; 
	virtual unsigned PopulationLimit() = 0;
	virtual unsigned PopulationRestore() = 0;
	virtual unsigned HunterMultiplier() = 0;
};

#endif