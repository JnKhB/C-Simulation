#include "CPrey.h"

void CPrey::Reproduction(unsigned numberOfRound)
{
	if (numberOfRound % ReproductionRound() == 0)
	{
		m_population *= ReproductionMultiplier();
	}
	if (m_population > PopulationLimit())
	{
		m_population = PopulationRestore();
	}
}
bool CPrey::Reduction(const CAnimal* pDependsOn)
{
	if (m_population >= pDependsOn->Population() * HunterMultiplier())
	{
		m_population -= pDependsOn->Population() * HunterMultiplier();
		return true; 
	}
	else
	{
		m_population = 0;
		return false; 
	}
}



